#Checkliste Code

- [ ] Gibt es keine offensichtliche Logikfehler im Code 
- [ ] Sind alle Variablen/Methoden etc. richtig und sprechend benannt (siehe Coding Guidelines -> Benennung)
- [ ] Sind alle relevant Tests geschrieben ("relevant" siehe Code-Guidelines -> Tests)
- [ ] Sind alle zuvor besprochenen Fehlerfälle abgedeckt? (StatusCodes)
- [ ] Gibt es keine Code-Duplikationen (bsp schon implementierte Teile in Komponenten)
- [ ] UI ist einheitlich (siehe Mockups) und Farben sind verwendet wie in Theme beschrieben 
- [ ] Ist die Codelänge in Ordnung? Wenn nein, wo gibt es Verbesserungspotenzial:

- [ ] Ist der Code verständlich geschrieben, wenn Nein an welchen Stellen ist er zu kompliziert:


- Allgemeine Kommentare:
