# Testing

Getestet wird mithilfe des Testsframeworks "Playwright"

## Was muss getestet werden?

Getestet werden muss alles was in Verbindung mit Nutzer-Eingaben passiert. Bedeutet, alle Validierungsfunktionen die Nutzereingaben validieren sollen.
